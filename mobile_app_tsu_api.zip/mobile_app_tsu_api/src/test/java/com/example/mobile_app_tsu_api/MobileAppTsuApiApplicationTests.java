package com.example.mobile_app_tsu_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobileAppTsuApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
