package api.controller;

import api.dto.TaskForScheduleDto;
import core.service.TaskForScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/tasks")
public class TaskForScheduleController {

    private final TaskForScheduleService taskService;

    @Autowired
    public TaskForScheduleController(TaskForScheduleService taskService) {
        this.taskService = taskService;
    }

    @GetMapping("/date/{date}")
    public ResponseEntity<List<TaskForScheduleDto>> getTasksByDate(@PathVariable LocalDate date) {
        List<TaskForScheduleDto> tasks = taskService.getTasksByDate(date);
        if (tasks.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return new ResponseEntity<>(tasks, HttpStatus.OK);
    }
    @PostMapping
    public ResponseEntity<TaskForScheduleDto> createOrUpdateTask(@RequestBody TaskForScheduleDto taskDto) {
        TaskForScheduleDto result = taskService.createOrUpdateTask(taskDto);
        return new ResponseEntity<>(result, HttpStatus.CREATED);
    }

}