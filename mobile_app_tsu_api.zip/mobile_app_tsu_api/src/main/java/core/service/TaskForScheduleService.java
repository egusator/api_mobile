package core.service;

import api.dto.TaskForScheduleDto;
import core.entity.TaskForSchedule;
import core.repository.TaskForScheduleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TaskForScheduleService {

    private final TaskForScheduleRepository repository;

    @Autowired
    public TaskForScheduleService(TaskForScheduleRepository repository) {
        this.repository = repository;
    }

    public List<TaskForScheduleDto> getTasksByDate(LocalDate date) {
        List<TaskForSchedule> tasks = repository.findByDate(date);
        return tasks.stream()
                .map(task -> new TaskForScheduleDto(
                        task.getId(),
                        task.getTaskId(),
                        task.getPeriodicTaskId(),
                        task.getWorkStart(),
                        task.getWorkEnd(),
                        task.getDate()
                ))
                .collect(Collectors.toList());
    }

    public TaskForScheduleDto createOrUpdateTask(TaskForScheduleDto taskDto) {
        TaskForSchedule task = new TaskForSchedule(
                taskDto.taskId(),
                taskDto.periodicTaskId(),
                taskDto.workStart(),
                taskDto.workEnd(),
                taskDto.date()
        );

        TaskForSchedule savedTask = repository.save(task);

        return new TaskForScheduleDto(
                savedTask.getId(),
                savedTask.getTaskId(),
                savedTask.getPeriodicTaskId(),
                savedTask.getWorkStart(),
                savedTask.getWorkEnd(),
                savedTask.getDate()
        );
    }
}