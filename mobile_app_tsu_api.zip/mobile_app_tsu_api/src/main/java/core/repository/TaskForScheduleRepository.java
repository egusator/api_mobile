package core.repository;

import core.entity.TaskForSchedule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;


@Repository
public interface TaskForScheduleRepository extends JpaRepository<TaskForSchedule, Integer> {
    List<TaskForSchedule> findByDate(LocalDate date);
}