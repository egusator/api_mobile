package com.example.mobile_app_tsu_api.api.dto;

import java.time.LocalDate;
import java.time.LocalTime;

public record TaskForScheduleDto(
        Integer id,
        Integer taskId,
        Integer periodicTaskId,
        LocalTime workStart,
        LocalTime workEnd,
        LocalDate date
) {}
