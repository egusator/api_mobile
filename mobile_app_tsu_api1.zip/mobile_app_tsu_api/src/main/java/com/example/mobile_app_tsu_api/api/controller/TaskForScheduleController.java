package com.example.mobile_app_tsu_api.api.controller;

import com.example.mobile_app_tsu_api.api.dto.TaskForScheduleDto;
import com.example.mobile_app_tsu_api.core.service.TaskForScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("api")
public class TaskForScheduleController {

    private final TaskForScheduleService taskService;

    @Autowired
    public TaskForScheduleController(TaskForScheduleService taskService) {
        this.taskService = taskService;
    }

    @GetMapping("/date")
    public ResponseEntity<List<TaskForScheduleDto>> getTasksByDate(@RequestParam(name = "date") LocalDate date) {
        List<TaskForScheduleDto> tasks = taskService.getTasksByDate(date);
        return new ResponseEntity<>(tasks, HttpStatus.OK);
    }
    @PostMapping("/task")
    public ResponseEntity<TaskForScheduleDto> createOrUpdateTask(@RequestBody TaskForScheduleDto taskDto) {
        TaskForScheduleDto result = taskService.createOrUpdateTask(taskDto);
        return new ResponseEntity<>(result, HttpStatus.CREATED);
    }

}