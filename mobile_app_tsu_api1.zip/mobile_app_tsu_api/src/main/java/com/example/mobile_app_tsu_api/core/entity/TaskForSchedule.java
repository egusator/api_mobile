package com.example.mobile_app_tsu_api.core.entity;


import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "task_for_schedule")  // Указываем имя таблицы
public class TaskForSchedule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // Автоматическая генерация идентификатора
    @Column(name = "id")  // Имя столбца в таблице
    private Integer id;

    @Column(name = "task_id")
    private Integer taskId;

    @Column(name = "periodic_task_id")
    private Integer periodicTaskId;

    @Column(name = "work_start")
    private LocalTime workStart;

    @Column(name = "work_end")
    private LocalTime workEnd;

    @Column(name = "date")
    private LocalDate date;

    // Конструкторы
    public TaskForSchedule() {
    }

    public TaskForSchedule(Integer taskId, Integer periodicTaskId, LocalTime workStart, LocalTime workEnd, LocalDate date) {
        this.taskId = taskId;
        this.periodicTaskId = periodicTaskId;
        this.workStart = workStart;
        this.workEnd = workEnd;
        this.date = date;
    }

    // Геттеры и сеттеры
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getTaskId() {
        return taskId;
    }

    public void setTaskId(Integer taskId) {
        this.taskId = taskId;
    }

    public Integer getPeriodicTaskId() {
        return periodicTaskId;
    }

    public void setPeriodicTaskId(Integer periodicTaskId) {
        this.periodicTaskId = periodicTaskId;
    }

    public LocalTime getWorkStart() {
        return workStart;
    }

    public void setWorkStart(LocalTime workStart) {
        this.workStart = workStart;
    }

    public LocalTime getWorkEnd() {
        return workEnd;
    }

    public void setWorkEnd(LocalTime workEnd) {
        this.workEnd = workEnd;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "TaskForSchedule{" +
                "id=" + id +
                ", taskId=" + taskId +
                ", periodicTaskId=" + periodicTaskId +
                ", workStart=" + workStart +
                ", workEnd=" + workEnd +
                ", date=" + date +
                '}';
    }
}